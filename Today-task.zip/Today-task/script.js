// Preparing data
let products = [
  {
    imgName: "../imgs/phone-1.jpeg",
    name: "Apple iPhone XR ((PRODUCT)RED, 64 GB) (Includes EarPods, Power Adapter)",
    ram: "64 GB ROM",
    display: "15.49 cm (6.1 inch) Display",
    camera: "12MP Rear Camera | 7MP Front Camera",
    processer: "A12 Bionic Chip Processor",
    os: "iOS 13 Compatible",
    warenty: "Brand Warranty of 1 Year",
    oldPrice: "47,90022 ",
    newPrice: "36,999",
    EMI: "No Cost EMI",
    off: "Upto ₹15,150 Off on Exchange",
  },
  {
    imgName: "../imgs/iphone-xr-red.png",
    name: "Apple iPhone XR ((PRODUCT)RED, 64 GB) (Includes EarPods, Power Adapter)",
    ram: "64 GB ROM",
    display: "15.49 cm (6.1 inch) Display",
    camera: "12MP Rear Camera | 7MP Front Camera",
    processer: "A12 Bionic Chip Processor",
    os: "iOS 13 Compatible",
    warenty: "Brand Warranty of 1 Year",
    oldPrice: "47,90022 ",
    newPrice: "36,999",
    EMI: "No Cost EMI",
    off: "Upto ₹15,150 Off on Exchange",
  },
  {
    imgName: "../imgs/phone-1.jpeg",
    name: "Apple iPhone XR ((PRODUCT)RED, 64 GB) (Includes EarPods, Power Adapter)",
    ram: "64 GB ROM",
    display: "15.49 cm (6.1 inch) Display",
    camera: "12MP Rear Camera | 7MP Front Camera",
    processer: "A12 Bionic Chip Processor",
    os: "iOS 13 Compatible",
    warenty: "Brand Warranty of 1 Year",
    oldPrice: "47,90022 ",
    newPrice: "36,999",
    EMI: "No Cost EMI",
    off: "Upto ₹15,150 Off on Exchange",
  },
];

// appraoch 2

let cards_new = "";
for (let i = 0; i < products.length; i++) {
  cards_new += `<div class="perent">  
               <div>
				<img src="${products[i].imgName}" alt="iphone">
                </div>
               
                <ul class="config">
                <h1>${products[i].name}</h1> 
                <li><p>${products[i].ram}</p></li>
                <li><p>${products[i].display}</p></li>
                <li><p>${products[i].camera}</p></li>
                <li><p>${products[i].processer}</p></li>
                <li><p>${products[i].os}</p></li>
                <li><p>${products[i].warenty}</p></li>
				</ul>
              
                <div class="price">
                <h3> Discounted Price:  &#8377; ${products[i].newPrice}</h3>
                <p> Old Price: &#8377; <del>${products[i].oldPrice}</del></p>
                <p>${products[i].EMI}</p>
                <h4>${products[i].off}</h4>
                </div>
                </div>
		`;
}

//document.getElementsByTagName('body')[0].innerHTML = cards_new;
document.getElementById("result_approach_2").innerHTML = cards_new;
